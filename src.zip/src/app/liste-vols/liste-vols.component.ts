
import { Vol } from './../model/vols.model';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { VolsService } from '../vols.service';

@Component({
  selector: 'app-liste-vols',
  templateUrl: './liste-vols.component.html',
  styleUrls: ['./liste-vols.component.css']
})
export class ListeVolsComponent implements OnInit {
  vols: Vol[] = [];
  selectedVol: Vol | undefined;
  constructor(private volsServ: VolsService) { }

  ngOnInit(): void {
    this.volsServ.findAll().subscribe(r => this.vols = r);
  }
  receiveChildrenEvt(vol: Vol): void {
    this.selectedVol = vol;
  }

  close(): void {
    this.selectedVol = undefined;
  }


}
