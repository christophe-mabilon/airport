import { RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ListeVolsComponent } from './liste-vols/liste-vols.component';
import { DetailsVolsComponent } from './details-vols/details-vols.component';
import { AjoutVolsComponent } from './ajout-vols/ajout-vols.component';
import { ReactiveFormsModule, FormGroup } from '@angular/forms';
import { MenuComponent } from "./menu/menu.component";
import { VolsComponent } from './vols/vols.component';
import { HttpClientModule } from '@angular/common/http';
import { DelteModalComponent } from './delte-modal/delte-modal.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';



@NgModule({
  declarations: [
    AppComponent,
    ListeVolsComponent,
    DetailsVolsComponent,
    AjoutVolsComponent,
    MenuComponent,
    VolsComponent,
    DelteModalComponent,PageNotFoundComponent,

  ],
  imports: [
    AppRoutingModule,BrowserModule,
     ReactiveFormsModule,
    NgbModule, HttpClientModule,RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
